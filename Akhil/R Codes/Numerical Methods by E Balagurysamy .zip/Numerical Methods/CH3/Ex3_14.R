#Example 14     Chapter 3       Page no.: 54
# Addition of floating numbers

x <- 0.735816E4
y <- 0.635742E4

z <- signif(x+y,6)

cat("x+y=",z)
cat("It can also be represented as 0.137156E5")