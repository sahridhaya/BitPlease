# Example 10     Chapter 3       Page no.: 52
# Floating point notation

x <- 0.00596
y <- 65.7452
z <- -486.8

cat(x,"is expressed as 0.596*10^(-2)")

cat(y,"is expressed as 0.657452*10^(2)")

cat(z,"is expressed as -0.4868*10^(3)")