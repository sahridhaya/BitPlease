# Example 11     Chapter 3       Page no.: 53
# Integer Arithmetics

a <- 25
b <- 12

cat("Addition        :",a,"+",b,"=",a+b)
cat("Subtraction     :",a,"-",b,"=",a-b)
cat("                :",b,"-",a,"=",b-a)
cat("Multiplication  :",a,"x",b,"=",a*b)
cat("Division        :",a,"/",b,"=",as.integer(a/b)) 
cat("Division        :",b,"/",a,"=",as.integer(b/a))