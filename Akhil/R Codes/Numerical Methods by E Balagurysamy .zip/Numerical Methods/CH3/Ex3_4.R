# Example 4     Chapter 3        Page no.: 48
# COnversion of Decimal number to Octal number

x<-163
a<-as.octmode(x)
cat("The number 163 is ")
a
cat("in Octal system")
