# Example 2     Chapter 3        Page no.: 46
# COnversion of Hexadecimal number to Decimal number

x<-'12af' #input value
a<-strtoi(x,16L)
cat("The Hex number 12AF is",a,"in Decimal system")