# Example 13     Chapter 3       Page no.: 54
# Addition of floating numbers

x <- 0.964572E2
y <- 0.586351E5

z <- signif(x+y,6)

cat("x+y=",z)
cat("It can also be represented as 0.587315E5")
