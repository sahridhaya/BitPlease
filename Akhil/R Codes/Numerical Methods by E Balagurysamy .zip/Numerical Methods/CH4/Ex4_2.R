# Example 2     Chapter 4       Page no.: 63
# Accuracy of numbers

C <- c("95.763", "0.008472", "0.0456000","36","3600","3600.00")

cat("Number of significant figures in",C[1],"is 5")
cat("Number of significant figures in",C[2],"is 4")
cat("Number of significant figures in",C[3],"is 6")
cat("Number of significant figures in",C[4],"is 2")
cat("Number of significant figures in",C[5],"is 2 and accuracy is not specified")
cat("Number of significant figures in",C[6],"is 6")