# Example 1     Chapter 4       Page no.: 63
# Precision of numbers

C <- c("4.3201", "4.32", "4.320106")
cat("Number of significant figures in",C[1],"is 5")
cat("Number of significant figures in",C[2],"is 3")
cat("Number of significant figures in",C[3],"is 7")

cat("The number",C[3],"has the greatest precision.")