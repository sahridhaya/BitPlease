The Fifth chapter ie. 'Vector Space '( Page No. 69 - 94) is purely theoretical mostly including concpts of,
Vector types, spaces, various axioms and theorems, properties etc.

This chapter don't contain numerical problems as such in solved examples or exercise questions.
Although this chapter contain very few Exercise questions most of them are either 'Proof Questions' or ' Variable Solution Questions'.
 The questions included are mostly property  type questions which asks us to prove the property in some type of vector space.