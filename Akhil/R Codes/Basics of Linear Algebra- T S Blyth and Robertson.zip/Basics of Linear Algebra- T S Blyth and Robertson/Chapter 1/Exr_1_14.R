# Exercise 14     Chapter: 1    Page No.: 8
# Vector Multiplication

a <- c(1,2,3,4)
c <- print(a %*% t(a))


