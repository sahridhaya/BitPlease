The Sixth chapter 'Linear Mapings' mainly deals with transformation or mapping of a funtion in a domain into another.
There are rarely any numerical problems to be solved in this chapter.
Neither any solved examples nor exercises have numerical problems.

Although this chapter contain very few Exercise questions most of them are either 'Proof Questions' or ' Variable Solution Questions' proving to be ina domain 
or to be proven as injective or surjective etc.
 