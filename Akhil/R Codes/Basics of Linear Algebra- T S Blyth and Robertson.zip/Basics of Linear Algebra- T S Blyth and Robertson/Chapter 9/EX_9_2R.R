# Example 2     Chapter 9       Page no.: 155
# Eigen values
# Include "Matrix" and "matlib" library
A <-  matrix(c(-3,1,-1,-7,5,-1,-6,6,-2), nrow = 3 , byrow = TRUE)
eigen(A)$values
