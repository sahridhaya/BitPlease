The seventh chapter ' The Matrix Connection' takes us into proving similarities betweeen matrices on different domains and on various transformations.
Most of the questions are either theoretical rasoning or determination of similaar matrices for computation.
This chapter don't contain numerical problems as such in solved examples or exercise questions.
Although this chapter contain very few Exercise questions most of them are either 'Proof Questions' or ' Variable Solution Questions'.
 