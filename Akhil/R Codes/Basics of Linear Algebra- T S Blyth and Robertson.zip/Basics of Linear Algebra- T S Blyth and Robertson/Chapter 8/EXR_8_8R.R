# Exercise 8     Chapter 8       Page no.: 139
# Determinant of matrix
# Include "Matrix" and "matlib" library
A <- matrix(c(1,2,3,-4,0,-5,6,-7,0,0,-8,9,0,0,0,10), nrow = 4, ncol = 4 , byrow = TRUE)
det(A)
