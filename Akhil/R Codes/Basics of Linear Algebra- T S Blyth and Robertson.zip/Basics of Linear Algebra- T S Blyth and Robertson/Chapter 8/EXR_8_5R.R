# Exercise 5     Chapter 8       Page no.: 138
# Determinant of matrix
# Include "Matrix" and "matlib" library

A <- matrix(c(1,2,-3,4,-4,2,1,3,3,0,-2,0,1,0,2,-5), nrow = 4, ncol = 4 , byrow = TRUE)
det(A)
