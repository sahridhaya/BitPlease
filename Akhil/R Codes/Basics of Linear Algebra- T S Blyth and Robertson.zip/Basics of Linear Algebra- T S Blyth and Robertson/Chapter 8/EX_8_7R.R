# Example 7     Chapter 8       Page no.: 138
# Determinant of matrix
# Include "Matrix" and "matlib" library
A <- matrix(c(1,1,-1,2,1,3,1,-5,1), nrow = 3, ncol = 3 , byrow = TRUE)
det(A)
