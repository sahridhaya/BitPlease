The second chapter ie. ' Some application of Matrices ' is purely theory based and it introduces the concept of,
1. Analytic geometry
2. System of linear Equations
3. Equillibrium-seeking systems
4. Difference Equations
5. Complex numbers

This chapter don't contain numerical problems as such in solved examples or exercise questions.
Although this chapter contain very few Exercise questions most of them are either 'Proof Questions' or ' Variable Solution Questions'.
 