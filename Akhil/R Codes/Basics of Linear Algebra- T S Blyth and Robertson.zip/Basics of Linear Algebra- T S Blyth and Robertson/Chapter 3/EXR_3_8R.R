# Exercise 8  Chapter: 3    PAge no.: 38
# Reducing to Hermite Form
# Include "Matrix" and "matlib" library
A <- matrix(c(1,-1,0,-1,-5,-1,2,1,-1,-4,1,-1,1,1,1,-4,-6,3,1,4,2,-8,-5,8), nrow = 4, ncol = 6, byrow = TRUE)
echelon(A)

# The answer obtained is a HERMITE matrix