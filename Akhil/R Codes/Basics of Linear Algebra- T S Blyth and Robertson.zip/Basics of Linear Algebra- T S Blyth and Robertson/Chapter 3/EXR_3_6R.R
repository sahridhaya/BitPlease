# Exercise 6  Chapter: 3    PAge no.: 36
# Reducing to Row Echelon Form of a 4x4 Matrix
# Include "Matrix" and "matlib" library
A <- matrix(c(1,2,0,3,1,1,2,3,3,3,1,0,1,1,3,1,1,1,2,1), nrow =4,ncol=5,byrow=TRUE)
echelon(A)

