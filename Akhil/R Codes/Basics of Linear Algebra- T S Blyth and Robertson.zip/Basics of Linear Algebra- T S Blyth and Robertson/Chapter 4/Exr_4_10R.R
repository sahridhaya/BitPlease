# Exercise 10  Chapter: 4    PAge no.: 68
# Inverse of a matrix
# Include "Matrix" and "matlib" library
A <- matrix(c(1,1,2,1,0,-2,0,0,1,2,1,-2,0,3,2,1), nrow =  4, ncol =4  , byrow = TRUE)
det(A)
inv(A)
