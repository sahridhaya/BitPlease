# Example 3  Chapter: 4    PAge no.: 63
# Inverse of a matrix
# Include "Matrix" and "matlib" library
A <- matrix(c(1,2,3,1,3,4,1,4,4), nrow = 3 , ncol = 3 , byrow = TRUE)
det(A)
inv(A)

# This is the simple inverse process. Here Inverse exists