#Example 7,section 3.1,page 185
#Evaluate determinant of matrix A:
 A<-matrix(c(1,2,3,2,1,1,3,3,2),c(3,3))
 print(A)
 det(A)
 