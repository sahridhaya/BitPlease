#Example 3, section 8.1, page 410
#Fin the eigenvectors and eigenvalues of matrix A:
A<-matrix(c(0,0,0,1),c(2,2))
A
eigen(A, only.value=FALSE)