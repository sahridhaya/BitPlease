#Example 3,section 4.1, page 216
#Show vector U in cartesian coordinate system:


u<-matrix(c(2,3),c(2,1))
print(u)
x <- c(0,2)
y <- c(0,3)
arrows(x[1],y[1],x[2],y[2])
