#Example 9,section 4.1, page 221
#Find u+v ,if u=(1,2) and v=(3,-4)  are two vectors  : 

u<-c(1,2)
v<-c(3,-4)
x0<- u[1] + v[1]
y0<- u[2] + v[2]
bill<- c(x0,y0)
print(bill)
plot(x0,y0)

