#Example 2, section 4.2, page 230
#If u=(1,-2,3) and v=(2,3,-3) are vectors in R3,then u+v is :

u<-c(1,-2,3)
v<-c(2,3,-3)

sum<- u+v
print(sum)