#Example 3, section 4.2, page 230
#if u=(2,3,-1,2) is a vector in R4 and c=-2, then find c*u :

u<-c(2,3,-1,2)
c=-2
final<- c*u
print(final) 