#Example 12, Section 1.2,page 15
#Find the difference of two matrices A and B:

A<- matrix(c(2,4,3,2,-5,1),c(2,3))
B<-matrix(c(2,3,-1,5,3,-2),c(2,3))
A<- A - B
print(A)